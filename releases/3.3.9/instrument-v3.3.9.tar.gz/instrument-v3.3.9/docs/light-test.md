# 3.3.4 设备测试、短录像和东八区

Flutter入口：设备 → 设备测试。背光滑杆0–100，松手后发送，设备确认成功后才显示已设置亮度。0为关闭，100为全亮；亮度保存到/opt/instrument/state/backlight.json，正常拍摄沿用。设备测试开始为关闭；结束、断线租约到期或正常退出关闭。GPIO55复用PWM11_M1，1kHz占空比=百分比；不采用软件PWM，也不变更接线。实体亮度均匀性与控制端兼容性需目视/模块参数验收。

不足3000ms：结果short，提示重拍，上下位机均不授权上传；视频保留在仪器，未自动删除。3000ms及以上且录像成功才可上传。旧固件2–3秒success在新Flutter中归为short，避免历史事件反复重试；不改写已经上传的历史文件。

调试JPEG仍为传感器1280×1080，质量95，缓冲与HTTP上限4MiB；Flutter显示900像素宽预览区域、400像素高画面，高质量缩放。压缩改善不能替代镜头对焦/曝光验收。

/etc/TZ与RKiPC/业务进程使用CST-8（POSIX符号为负，表示UTC+8）。系统时钟、RTC、协议started_at_ms继续存UTC，不能将epoch加8小时。Flutter统一beijingTime显示，北京时间17:12对应09:12Z；16:00Z跨日显示次日00:00。

构建/回归：make all mux-adapter；make check-host；python3 tests/test_capture_minimum.py；python3 tests/test_backlight.py；python3 tests/test_diagnostics_backlight.py；python3 tests/test_light.py；python3 tests/test_status_light.py；python3 tests/test_pair_lights.py。

安装使用完整instrument-v3.3.4.tar.gz，先核对设备序列号/应用ID/空闲状态。现有deploy/install_bundle.sh --install --idle-confirmed --replace-startup保存旧文件与校验，/etc/TZ也在install-map内；配置、配对、视频不覆盖。安装前人工核对启动脚本差异。启动新版业务与RKiPC后核对版本、文件校验、JPEG参数、进程TZ和实际录像。

回退：在设备空闲并停止instrument_app/rkipc后，按安装记录existing-files.txt、new-files.txt恢复同目录rollback-files.tar中的明确旧路径；无旧/etc/TZ时移走新/etc/TZ。相机配置的本轮修改前副本单独保存于本轮设备backups目录，恢复后按原LD_PRELOAD启动相机。保留所有待传数据。

以下为历史独立灯光测试说明：

# 3.3.3 背光时序与硬件初始化收拢

- 上位机允许拍摄时，左右键连续按住0.5秒打开背光；松开任意一个键后1秒关闭。短按不亮，等待关闭期间再次按住会取消关闭。
- 实际录制仍在左右键按住1.5秒后开始。背光计时不等待录像/上传结束；权限失效、读键错误、采样中断、正常退出立即关闭。
- app/runtime_v3.c给出拍摄权限；middleware/buttons.c统一计时；platform/light_test.c输出GPIO55及PWM，platform/luckfox_gpio.c初始化输入。
- 原button_inputs.sh与light_pwm.sh逻辑编译进硬件层，用现有sh/devmem/dtc执行，不生成永久脚本文件；移植只修改platform。
- 新payload/deploy保留RkLunch.sh（SDK相机/内核/网络启动）、S80instrument（Linux开机入口）、install_bundle.sh（备份校验安装）、wpa_supplicant.default.conf（默认配置）、README.md。这些不属于日常业务状态机。
- 安装器先将旧button_inputs.sh、light_pwm.sh、S79buttons逐个纳入rollback-files.tar，再逐个移除。旧3.3.2包不修改。
- validation为测试提取目录、日志、构建工具和本地回退副本，不参与运行；原始日志退出Git，保留capture-results-20261002/README.md历史验收摘要及必要回退副本。test_bundle改用临时目录，检查后不留解包树。
- tests/test_backlight.py验证真实计时服务与GPIO写入边界，其他灯态/配对/上传/删除/打包回归继续运行。自动验证不能代替物理目视与断电验收。

下文为历史说明，历史helper路径仅适用于3.3.1/3.3.2。

# 3.3.2 配对状态灯与45秒窗口

- 正常模式中键灯常亮；进入配对窗口中键灯以3秒周期呼吸。
- 未配对时长按中键3秒开启45秒窗口，再次长按立即退出；已配对时沿用原解除配对动作。
- 45秒从长按被识别并开启窗口时计时；超时清空窗口及候选事务，恢复常亮，只排队一次退出语音。
- 配对成功立即恢复常亮并播放原成功语音，不再触发超时退出语音。
- 进入语音：已进入配对模式，请在电脑上选择仪器。四十五秒后自动退出。
- 退出语音：配对模式已关闭，已恢复正常模式。
- 业务灯与独立灯测共用PWM/GPIO和flock锁；业务程序运行时独立灯测会拒绝占用。独立测试前须先停止业务，退出时再恢复业务。背光仍为独立手动控制。
- 正常服务TERM/INT退出先灭灯并释放PWM/overlay/GPIO32。掉电或SIGKILL仍需重启恢复；接线沿用用户已核对回路，高电平有效，实体灯亮度/极性仍待本轮目视确认。
- tests/test_status_light.py验证实际PWM写入路径；tests/test_pair_lights.py启动真实协调器验证45秒、手动取消、配对成功和超时只触发一次；既有回归继续执行。

以下保留3.3.1独立灯测说明，3.3.2状态行为以上文为准。

# 3.3.1 中键灯与背光调试

2026-10-07。固件真实源码：WSL2 Luckfox-Ubuntu-22.04:/home/guanjx/luckfox/Scoliosis。
本轮增加独立调试入口，先于配置加载和业务初始化执行；左右键、中键业务、配对与拍摄流程不变。

## 接线与核验

| 模块 | 项目针号 | 系统编号/接口 |
|---|---|---|
| MF168 OUT | 40 | GPIO0_A4 / GPIO4；仍是按键输入 |
| MF168 VCC | 1 | 3.3V |
| MF168 GND | 5 | GPIO1_A0 / GPIO32，测试中仅输出低电平 |
| MF168 LED | 35 | GPIO0_A1 / PWM2_M0 |
| G24D-5733 电源 | 2、25 | 5V、固定GND |
| G24D-5733 LED控制 | 36 | GPIO1_C7 / GPIO55 |

用户已回复“核对正确”。未提供电流、电压数值，软件记录不能替代实际电气测量。中键命令必须显式加入 --ground-verified；该参数表示操作者已核验回路，不是软件测量结果。不自行改线。

## 板端命令

安装后的程序和 helper 位于 /opt/instrument/bin；helper 与程序同目录。
临时验证使用 /tmp/instrument-light-test-331，同一入口。

~~~sh
/opt/instrument/bin/instrument_app --light-test center off --ground-verified
/opt/instrument/bin/instrument_app --light-test center on --ground-verified
/opt/instrument/bin/instrument_app --light-test center slow --ground-verified
/opt/instrument/bin/instrument_app --light-test center fast --ground-verified
/opt/instrument/bin/instrument_app --light-test center breathe --ground-verified
/opt/instrument/bin/instrument_app --light-test backlight on
/opt/instrument/bin/instrument_app --light-test backlight off
~~~

默认30秒，--seconds 1..300 可缩短。默认高电平有效；若模块控制逻辑反向，核验后使用 --active-low，仍然在结束时关闭输出。

- 慢闪：亮、灭各1秒；快闪：亮、灭各0.125秒。
- 呼吸：3秒线性上升/下降；PWM周期1,000,000ns（1kHz），15ms更新占空比。
- 复用示例 gpio.c/pwm.c 的 Linux sysfs；修正示例无限循环、PWM编号固定和缺少清理的问题。
- light_pwm.sh 复用板上 luckfox-config 的 configfs overlay 机制，读取当前 PWM2_M0 phandle，仅启用 /pwm@ff350020；不修改 /etc/luckfox.cfg、不写开机配置。
- Rockchip PWM 要先设置 period，再设置 duty/enable。按设备物理路径 ff350020.pwm 找 pwmchip，不能固定成 pwmchip0/10。
- Linux flock 拒绝并发测试；已有 GPIO/PWM占用、PWM不可用、参数错误均明确报错；没有软件 PWM 替代。
- 正常超时、SIGINT、SIGTERM、SIGHUP、可处理的 I/O错误均执行灭灯/取消导出/撤销 overlay。SIGKILL、掉电、内核异常无法执行用户态清理；异常时重启复位，不承诺这些场景自动灭灯。
- 返回0为软件调用和清理成功；2为参数/身份/回路核验错误；1为硬件接口失败；信号退出为128+信号。

## Python中间层

入口：Windows 调试/工具/Python中间层/light_test.py。
复用现有 Paramiko、SSH known_hosts 和板端入口，不新增网络协议、后台服务或 Flutter功能。
SSH主机密钥、板序列号、config.json设备ID、active-v3.json和writing目录都必须通过检查；未知主机密钥拒绝自动信任，密码只交互输入或标准输入，不写日志。

~~~powershell
python 调试/工具/Python中间层/light_test.py --address 实际板IP --serial 41eda5f2c5b00de1 --device-id CAM-41eda5f2c5b00de1 backlight on
python 调试/工具/Python中间层/light_test.py --address 实际板IP --serial 41eda5f2c5b00de1 --device-id CAM-41eda5f2c5b00de1 --ground-verified center breathe
~~~

现场没有Wi-Fi地址，本次真实SSH验证走既有ADB转发：

~~~powershell
adb -s 41eda5f2c5b00de1 forward tcp:12222 tcp:22
python 调试/工具/Python中间层/light_test.py --address 127.0.0.1 --port 12222 --host-key-name 192.168.101.3 --serial 41eda5f2c5b00de1 --device-id CAM-41eda5f2c5b00de1 --app /tmp/instrument-light-test-331/instrument_app backlight on
~~~

host-key-name 是旧 known_hosts 中的已核对密钥别名，不是当前板IP。实板以序列号与设备ID再次核对。本次板的公开SSH密钥也通过指定ADB序列号读取公钥交叉核对。
日志默认绝对路径：D:/code/Scoliosis/Luckfox/调试/记录/light-test-20261007/python-light.jsonl。
Python窗口被中断或SSH连接丢失时，远端仍有自己的30秒/指定时限，最长300秒；不保证客户端断开即刻灭灯。

## 构建、发布与回退

~~~sh
cd /home/guanjx/luckfox/Scoliosis
make all mux-adapter
python3 tests/test_light.py
make check-host
# Reviewed source must be committed before packaging.
sh scripts/package_image.sh 3.3.1
bash scripts/package_bundle.sh 3.3.1
python3 tests/test_bundle.py releases/3.3.1/instrument-v3.3.1.tar.gz
~~~

新正式路径统一为 releases/3.3.1；payload/包含完整程序、20个音频、适配库、配置示例、启动、GPIO及安装文件。发布目录不可覆盖；正式版本每次递增末位，其他版本位仅按用户通知调整。
BUILD.txt记录源码提交，注释tag instrument-v3.3.1记录功能与压缩包SHA-256；发布文件提交与源码提交分别记录。
Windows镜像只复制完整压缩包、SHA256SUMS、BUILD.txt、VERSION.md，不创建可编辑固件副本。
旧版本标签及必要回退证据保留；清理明细单独记录，不删除真实配置、配对、视频和板上回退备份。

解包与安装使用现有 deploy/install_bundle.sh --check / --install --idle-confirmed；不要把应用包当 update.img 刷机。
安装前停止拍摄、上传、灯光测试和相关服务，核对身份及启动脚本；所有改动由安装脚本备份到 /opt/instrument/backups/bundle-*/rollback-files.tar。
回退3.3.0可以安装 releases/3.3.0 中的完整上一正式包，或在空闲并停止服务后恢复本次安装前的 rollback-files.tar；原 config/pair/state/pending 保留。

## 验证边界

自动验证覆盖五种灯态的计算与板端调用、PWM实际驱动、GPIO设置、超时和信号清理、并发拒绝、Python身份核对、完整包与既有业务主机回归。
实板记录见 Windows 调试/记录/light-test-20261007/board-tests.json。

实体灯是否亮灭正确、呼吸是否平滑、实际回路电流/电压、实际按下三键、断电再上电后的外设状态仍需人工验收。命令退出0不能代替目视或电气测量。


## 3.3.5 灯态与PWM修正（2026-10-08）

亮度0%关闭、100%全亮；中间值由板端统一修正反向PWM，上位机仍发送0–100真实亮度语义。
中键配对呼吸；连接正常常亮；未配对或配对电脑15秒无查询慢闪；按键输入失败/Wi-Fi needs_attention快闪；进程正常退出熄灭。
低电预留为2秒周期双闪，ADC未校准接入前不触发。故障优先于低电，低电优先于配对。
实板验收时停止拍摄、上传和设备测试；升级核对序列号、设备ID和主机密钥。逐项检查0/25/50/75/100亮度、断线、恢复、配对和关闭。不要把软件回归视为实体或电气验收。


## 3.3.6 GPIO端点修复

实板0%关闭异常由PWM11移除后C7复用仍为3引起。GPIO55重新获取后恢复C7复用为GPIO，仅更新0xff538014位12..15并核对其余位不变。真实0/100端点、25/50/75切换及结束/重启后的关闭状态需要实板读回；按键本体已由用户确认，本轮不重复验收。
