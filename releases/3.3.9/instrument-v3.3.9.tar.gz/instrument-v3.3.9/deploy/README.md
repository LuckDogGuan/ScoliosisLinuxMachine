# 3.3.3 部署文件职责

输入按键和PWM硬件初始化已经编译进platform，应用不依赖同目录.sh。新发布包仅保留SDK启动RkLunch.sh、系统服务S80instrument、安装器、默认Wi-Fi配置与说明。安装器对旧硬件helper先备份再逐个清理。移植时修改platform，业务及计时留在app/middleware。

以下历史操作以实际版本包文件为准。

# 当前 Luckfox 板部署文件

S80instrument 安装位置为 `/oem/usr/etc/init.d/S80instrument`；RkLunch.sh 为本板当前 `/RkLunch.sh`，仅对 RKiPC 注入 `luckfox_mux_adapter.so`，保留原厂其他启动逻辑。移植另一块 Linux 板时重新核对平台和启动配置。

版本包程序和库放 `/opt/instrument/bin/`，声音放 `/opt/instrument/sounds/`。保留现场 `/opt/instrument/config.json`、配对身份、Wi-Fi、capture/pending、state/events 和上位机学生关联。示例配置仅用于首次初始化，不覆盖已有配置。换程序前关闭电脑拍摄许可，等待当前录像和文件收尾，再备份程序及配置。恢复程序后通过重启或 init 脚本正常启动，读取真实 GPIO。

回滚使用 `image/baseline-20261001/instrument_app` 与原 RkLunch.sh，并参考板端 `/opt/instrument/backups/before-ui-pair-layer-20261001-1522.tar` 的单独配置。不要整目录恢复覆盖新视频及新增归属数据。


## 3.3.1 独立灯光调试

正式包路径：releases/3.3.1/instrument-v3.3.1.tar.gz。安装脚本同时安装 light_pwm.sh 到程序同目录；不自动点灯。灯态、接线、核验和验收边界见 docs/light-test.md（发布包见 VERSION.md）。
