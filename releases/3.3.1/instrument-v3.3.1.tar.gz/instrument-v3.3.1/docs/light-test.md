# 3.3.1 中键灯与背光调试

2026-10-07。固件真实源码：WSL2 Luckfox-Ubuntu-22.04:/home/guanjx/luckfox/Scoliosis。
本轮增加独立调试入口，先于配置加载和业务初始化执行；左右键、中键业务、配对与拍摄流程不变。

## 接线与核验

| 模块 | 项目针号 | 系统编号/接口 |
|---|---|---|
| MF168 OUT | 40 | GPIO0_A4 / GPIO4；仍是按键输入 |
| MF168 VCC | 1 | 3.3V |
| MF168 GND | 5 | GPIO1_A0 / GPIO32，测试中仅输出低电平 |
| MF168 LED | 35 | GPIO0_A1 / PWM2_M0 |
| G24D-5733 电源 | 2、25 | 5V、固定GND |
| G24D-5733 LED控制 | 36 | GPIO1_C7 / GPIO55 |

用户已回复“核对正确”。未提供电流、电压数值，软件记录不能替代实际电气测量。中键命令必须显式加入 --ground-verified；该参数表示操作者已核验回路，不是软件测量结果。不自行改线。

## 板端命令

安装后的程序和 helper 位于 /opt/instrument/bin；helper 与程序同目录。
临时验证使用 /tmp/instrument-light-test-331，同一入口。

~~~sh
/opt/instrument/bin/instrument_app --light-test center off --ground-verified
/opt/instrument/bin/instrument_app --light-test center on --ground-verified
/opt/instrument/bin/instrument_app --light-test center slow --ground-verified
/opt/instrument/bin/instrument_app --light-test center fast --ground-verified
/opt/instrument/bin/instrument_app --light-test center breathe --ground-verified
/opt/instrument/bin/instrument_app --light-test backlight on
/opt/instrument/bin/instrument_app --light-test backlight off
~~~

默认30秒，--seconds 1..300 可缩短。默认高电平有效；若模块控制逻辑反向，核验后使用 --active-low，仍然在结束时关闭输出。

- 慢闪：亮、灭各1秒；快闪：亮、灭各0.125秒。
- 呼吸：3秒线性上升/下降；PWM周期1,000,000ns（1kHz），15ms更新占空比。
- 复用示例 gpio.c/pwm.c 的 Linux sysfs；修正示例无限循环、PWM编号固定和缺少清理的问题。
- light_pwm.sh 复用板上 luckfox-config 的 configfs overlay 机制，读取当前 PWM2_M0 phandle，仅启用 /pwm@ff350020；不修改 /etc/luckfox.cfg、不写开机配置。
- Rockchip PWM 要先设置 period，再设置 duty/enable。按设备物理路径 ff350020.pwm 找 pwmchip，不能固定成 pwmchip0/10。
- Linux flock 拒绝并发测试；已有 GPIO/PWM占用、PWM不可用、参数错误均明确报错；没有软件 PWM 替代。
- 正常超时、SIGINT、SIGTERM、SIGHUP、可处理的 I/O错误均执行灭灯/取消导出/撤销 overlay。SIGKILL、掉电、内核异常无法执行用户态清理；异常时重启复位，不承诺这些场景自动灭灯。
- 返回0为软件调用和清理成功；2为参数/身份/回路核验错误；1为硬件接口失败；信号退出为128+信号。

## Python中间层

入口：Windows 调试/工具/Python中间层/light_test.py。
复用现有 Paramiko、SSH known_hosts 和板端入口，不新增网络协议、后台服务或 Flutter功能。
SSH主机密钥、板序列号、config.json设备ID、active-v3.json和writing目录都必须通过检查；未知主机密钥拒绝自动信任，密码只交互输入或标准输入，不写日志。

~~~powershell
python 调试/工具/Python中间层/light_test.py --address 实际板IP --serial 41eda5f2c5b00de1 --device-id CAM-41eda5f2c5b00de1 backlight on
python 调试/工具/Python中间层/light_test.py --address 实际板IP --serial 41eda5f2c5b00de1 --device-id CAM-41eda5f2c5b00de1 --ground-verified center breathe
~~~

现场没有Wi-Fi地址，本次真实SSH验证走既有ADB转发：

~~~powershell
adb -s 41eda5f2c5b00de1 forward tcp:12222 tcp:22
python 调试/工具/Python中间层/light_test.py --address 127.0.0.1 --port 12222 --host-key-name 192.168.101.3 --serial 41eda5f2c5b00de1 --device-id CAM-41eda5f2c5b00de1 --app /tmp/instrument-light-test-331/instrument_app backlight on
~~~

host-key-name 是旧 known_hosts 中的已核对密钥别名，不是当前板IP。实板以序列号与设备ID再次核对。本次板的公开SSH密钥也通过指定ADB序列号读取公钥交叉核对。
日志默认绝对路径：D:/code/Scoliosis/Luckfox/调试/记录/light-test-20261007/python-light.jsonl。
Python窗口被中断或SSH连接丢失时，远端仍有自己的30秒/指定时限，最长300秒；不保证客户端断开即刻灭灯。

## 构建、发布与回退

~~~sh
cd /home/guanjx/luckfox/Scoliosis
make all mux-adapter
python3 tests/test_light.py
make check-host
# Reviewed source must be committed before packaging.
sh scripts/package_image.sh 3.3.1
bash scripts/package_bundle.sh 3.3.1
python3 tests/test_bundle.py releases/3.3.1/instrument-v3.3.1.tar.gz
~~~

新正式路径统一为 releases/3.3.1；payload/包含完整程序、20个音频、适配库、配置示例、启动、GPIO及安装文件。发布目录不可覆盖；正式版本每次递增末位，其他版本位仅按用户通知调整。
BUILD.txt记录源码提交，注释tag instrument-v3.3.1记录功能与压缩包SHA-256；发布文件提交与源码提交分别记录。
Windows镜像只复制完整压缩包、SHA256SUMS、BUILD.txt、VERSION.md，不创建可编辑固件副本。
旧版本标签及必要回退证据保留；清理明细单独记录，不删除真实配置、配对、视频和板上回退备份。

解包与安装使用现有 deploy/install_bundle.sh --check / --install --idle-confirmed；不要把应用包当 update.img 刷机。
安装前停止拍摄、上传、灯光测试和相关服务，核对身份及启动脚本；所有改动由安装脚本备份到 /opt/instrument/backups/bundle-*/rollback-files.tar。
回退3.3.0可以安装 releases/3.3.0 中的完整上一正式包，或在空闲并停止服务后恢复本次安装前的 rollback-files.tar；原 config/pair/state/pending 保留。

## 验证边界

自动验证覆盖五种灯态的计算与板端调用、PWM实际驱动、GPIO设置、超时和信号清理、并发拒绝、Python身份核对、完整包与既有业务主机回归。
实板记录见 Windows 调试/记录/light-test-20261007/board-tests.json。

实体灯是否亮灭正确、呼吸是否平滑、实际回路电流/电压、实际按下三键、断电再上电后的外设状态仍需人工验收。命令退出0不能代替目视或电气测量。
